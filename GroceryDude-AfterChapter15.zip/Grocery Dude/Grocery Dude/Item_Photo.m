//
//  Item_Photo.m
//  Grocery Dude
//
//  Created by Tim Roadley on 24/09/13.
//  Copyright (c) 2013 Tim Roadley. All rights reserved.
//

#import "Item_Photo.h"
#import "Item.h"


@implementation Item_Photo

@dynamic data;
@dynamic item;

@end
