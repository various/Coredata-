//
//  Unit.m
//  Grocery Dude
//
//  Created by Tim Roadley on 24/09/13.
//  Copyright (c) 2013 Tim Roadley. All rights reserved.
//

#import "Unit.h"
#import "Item.h"


@implementation Unit

@dynamic name;
@dynamic modified;
@dynamic items;

@end
