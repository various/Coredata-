//
//  Unit.m
//  Grocery Cloud
//
//  Created by Tim Roadley on 25/09/13.
//  Copyright (c) 2013 Tim Roadley. All rights reserved.
//

#import "Unit.h"
#import "Item.h"


@implementation Unit

@dynamic name;
@dynamic createddate;
@dynamic lastmoddate;
@dynamic unit_id;
@dynamic items;

@end
