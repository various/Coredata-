//
//  LocationAtHome.m
//  Grocery Cloud
//
//  Created by Tim Roadley on 25/09/13.
//  Copyright (c) 2013 Tim Roadley. All rights reserved.
//

#import "LocationAtHome.h"
#import "Item.h"


@implementation LocationAtHome

@dynamic storedIn;
@dynamic locationathome_id;
@dynamic items;

@end
