//
//  Location.m
//  Grocery Cloud
//
//  Created by Tim Roadley on 25/09/13.
//  Copyright (c) 2013 Tim Roadley. All rights reserved.
//

#import "Location.h"


@implementation Location

@dynamic summary;

@end
