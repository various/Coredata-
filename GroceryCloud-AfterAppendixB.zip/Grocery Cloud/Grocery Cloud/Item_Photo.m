//
//  Item_Photo.m
//  Grocery Cloud
//
//  Created by Tim Roadley on 25/09/13.
//  Copyright (c) 2013 Tim Roadley. All rights reserved.
//

#import "Item_Photo.h"
#import "Item.h"


@implementation Item_Photo

@dynamic data;
@dynamic item;

@end
