//
//  Test.m
//  EasyiCloud
//
//  Created by Tim Roadley on 24/09/13.
//  Copyright (c) 2013 Tim Roadley. All rights reserved.
//

#import "Test.h"


@implementation Test

@dynamic modified;
@dynamic someValue;
@dynamic device;

@end
