//
//  ShopTVC.h
//  Grocery Dude
//
//  Created by Tim Roadley on 19/09/13.
//  Copyright (c) 2013 Tim Roadley. All rights reserved.
//

#import "CoreDataTVC.h"

@interface ShopTVC : CoreDataTVC

@end
